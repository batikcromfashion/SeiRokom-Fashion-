# SeiRokom Fashion — Secure Gemini Backend

This backend connects the GitHub Pages `Generative AI` button to Gemini without exposing the Gemini API key in `index.html`.

## What it uses

- Vercel Functions (Node.js)
- Gemini 3.7 Flash
- Server-side environment variable: `GEMINI_API_KEY`

Google's current Gemini documentation recommends keeping API keys server-side and using environment variables. Do not commit a real API key to GitHub.

## Deploy

1. Create a new GitHub repository, for example `seirokom-fashion-ai-backend`.
2. Upload this folder's contents, including the `api` folder.
3. Import that repository into Vercel and deploy it.
4. In Vercel → Project → Settings → Environment Variables, add:
   - Name: `GEMINI_API_KEY`
   - Value: your Gemini API key
   - Environment: Production (and Preview if you want testing)
5. Add another variable:
   - Name: `ALLOWED_ORIGIN`
   - Value: your actual GitHub Pages origin, for example `https://username.github.io`
6. Redeploy after changing environment variables.
7. Your endpoint will be:
   `https://YOUR-VERCEL-PROJECT.vercel.app/api/ai`

## Connect the website

In `index.html`, set:

```html
<script>
  window.SEIROKOM_AI_ENDPOINT = "https://YOUR-VERCEL-PROJECT.vercel.app/api/ai";
</script>
```

Place that before the Generative AI script, or replace the existing placeholder endpoint line.

## Important security rule

Never put `GEMINI_API_KEY` inside `index.html`, GitHub, JavaScript served to visitors, or screenshots.

The browser sends the customer's message to `/api/ai`; the Vercel function sends it to Gemini using the private server-side key.

## Test

Open:

`https://YOUR-VERCEL-PROJECT.vercel.app/api/ai`

A GET request is intentionally rejected. Test through the website's Generative AI button with a POST request.

## Notes

- Exact live product stock/prices are not connected yet. The AI is instructed not to invent them.
- For live catalog-aware answers later, the backend can be connected to a product database/API.
- AI usage may incur Google AI/Gemini charges depending on your account and usage.
